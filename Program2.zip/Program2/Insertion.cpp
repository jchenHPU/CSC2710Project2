#include<iostream>
using namespace std;
/*
Tarun Baskar
csc2710-01
3/1/2022

Program 2: Team programming assignment on sorting(Insertion)

In this part of the program I have included my algorithm for insertion sort, which will sort a basic unsorted(randomly distributed) array in order from least to greatest and have included everything I needed to in the algorithm below.
*/

int main()
{
 int array[30] = {12, 4, 3, 1, 15, 45, 33, 21, 10, 2, 30, 11, 65, 14, 59, 63, 59, 101, 243, 30, 90, 84, 8, 10, 345, 94, 27, 43, 6, 100};//list that is going to be sorted
 
 cout<<"List before being sorted: "<<endl;
 for(int i =0; i<30; i++)//for loop for displaying the array before being sorted
 {
  cout<<array[i]<<" ";
 }
 cout<<endl;
 cout<<" "<<endl;//for formatting purposes
 
 for(int k = 1; k<30; k++)//for loop which includes insertion sort algorithm
 {
  int temp = array[k];
  int j = k-1;
  while(j >= 0 && temp <= array[j])
  {
   array[j+1] = array[j];
   j = j-1;
  }
  array[j+1] = temp;
 }
 //end of insertion sort algorithm

 cout<<"Array after being sorted: "<<endl;
 for(int i =0; i<30; i++)//for loop for displaying the sorted array
 {
  cout<<array[i]<<" ";
 }
 cout<<endl;

 return 0;
}
 

#include<iostream>
using namespace std;
/*
Tarun Baskar
csc2710-01
3/3/2022

Program 2: Team programming assignment with sorting

In this part of the program I have implimented my code for Heap sort, which sorts out an almost sorted dataset
*/

void heapify(int arr[], int n, int root)//function to heapify the tree
{
 int largest = root; //root is the largest element
 int l = 2*root + 1; //left = 2*root + 1
 int r = 2*root + 2; //right = 2*root + 2

 if(l < n && arr[l] > arr[largest])//if left child is larger than root
  largest = l;
 
 if(r < n && arr[r] > arr[largest])//If right child is larger than largest
  largest = r;

 if(largest != root)//if largest is not root
 {
  swap(arr[root], arr[largest]);//swap root and largest
 
  heapify(arr, n, largest);//Heapify sub-tree using recursion
 }
}
//End of heapify function

void heapSort(int arr[], int n)//function implimenting Heap sort
{
 for(int i = n/2 -1; i >= 0; i--)//build heap
 heapify(arr, n, i);
 
 for(int i = n-1; i >= 0; i--)//extracting elements from heap one by one
 {
   swap(arr[0], arr[i]);
 
   heapify(arr, i, 0);
 }
}
//End of Heap sort function

void displayArray(int arr[], int n)//function to display the array
{
 for(int i = 0; i<n; ++i)
  cout<<arr[i]<<" ";
  cout<<endl;
}
//end of display function

int main()
{
 int heap_arr[] = {1, 2, 6, 7, 12, 9, 11, 27, 20};
 int n = sizeof(heap_arr)/sizeof(heap_arr[0]);
 cout<<"Array before being sorted: "<<endl;
 displayArray(heap_arr, n);//displays the array before it gets sorted
 
 heapSort(heap_arr, n);//calls heap sort function to sort the array
 cout<<"Array after being sorted: "<<endl;
 displayArray(heap_arr, n);//displays the sorted array

 return 0;
}
//end of main function

//end of program

#include<iostream>
using namespace std;
/*
Tarun Baskar
csc2710-01
2/28/2022

Program 2: Team programming assignment on sorting(Bubble)

In this part of the program I included the algorithm for Bubble sort where it includes a reverse sorted list of numbers which will then be sorted by bubble sort. I have also included the number of passes it took to sort the list.
*/

int main()
{
 int i, j, temp, pass = 0;
 int array[20] = {263, 189, 135, 115, 106, 97, 91, 86, 79, 70, 65, 63, 55, 42, 39, 30, 29, 28, 19, 8};//array that will be sorted
  
 cout<<"List before being sorted: "<<endl;
 for(i = 0; i<20; i++)//for loop for displaying the list before being sorted
 {
  cout<<array[i]<<" ";
 }
 cout<<endl;
 cout<<" "<<endl;//for formatting purposes
 
 for(i = 0; i<20; i++)//Bubble sort algorithm begins
 {
   for(j = i+1; j<20; j++)
   {
    if(array[j]<array[i])
    {
     temp = array[i];
     array[i] = array[j];
     array[j] = temp;
    }
   }
  pass++;//adds to number of passes
 }
 //end of bubble sort algorithm
 
 cout<<"Array after being sorted: "<<endl;
 for(i = 0; i<20; i++)//for loop for displaying the sorted array
 {
  cout<<array[i]<<" ";
 }
 cout<<endl;
 cout<<" "<<endl;//for formatting purposes
 
 cout<<"Number of passes taken to sort: "<<pass<<endl;//displays number of passes

 return 0;
}

#include<iostream>
using namespace std;
/*
Name: Tarun Baskar
csc2710-01
2/16/2022

Program 2: Team Programming Assignment on Sorting algorithms(Selection Sort)

In this part of the program my algorithm for selection sort is included which includes the main function which carries out the sorting algorithm and another function for finding the smallest element in the array. I have also inlcuded the number of passes that the sorting algorithm carries out.
*/

int findSmallest(int myarray[], int i);//function for finding the smallest integer.

int main()
{
 int myarray[20] = {11, 5, 2, 20, 42, 53, 23, 34, 101, 22, 12, 49, 13, 69, 234, 16, 89, 95, 73, 222};//array that is going to be sorted.
 int pos, temp, pass = 0;

 cout<<"Array before being sorted: "<<endl;//displays array before being sorted.
 for(int i=0; i<20; i++)
 {
   cout<<myarray[i]<<" ";
 }
 cout<<endl;
 cout<<" "<<endl;

 for(int i=0; i<20; i++)//where selection sort happens
 {
  pos = findSmallest(myarray, i);
  temp = myarray[i];
  myarray[i] = myarray[pos]; 
  myarray[pos] = temp;
  pass++;//adds to number of passes it takes to sort
 }

 cout<<"Sorted list of elements: "<<endl;//displays the final sorted array
 for(int i=0; i<20; i++)
 {
  cout<<myarray[i]<<" ";
 }
 cout<<endl;
 cout<<"  "<<endl;

 cout<<"Number of passes required to sort the array: "<<pass<<endl;//displays number of total passes

 return 0;
}
//end of main function

int findSmallest(int myarray[], int i)//function to find the smallest value of the array
{
 int small, position, j;
 small = myarray[i]; 
 position = i;
 for(j = i+1; j<10; j++)
 {
  if(myarray[j]<small)
  {
    small = myarray[j];
    position = j;
  }
 }
 return position;
}
//end of findSmallest function

#include<iostream>
using namespace std;
/*
Tarun Baskar
csc2710-0
3/2/2022

Program 2: Team programming assignment using sorting

In this part of the program my algorithm for quick sort is included, For this part I included a dataset that has many duplicates involved. 
*/

void swap(int *a, int *b)//swaps two elements
{
 int t = *a;
 *a = *b;
 *b = t;
}
//end of swap function
 
int partition(int arr[], int low, int high)//partition function
{
 int pivot = arr[high];
 int i = (low - 1);
 
 for(int j = low; j <= high- 1; j++)
 {
   if(arr[j] <= pivot)//if current element is smaller than pivot, increment low element
   //swap elements at i and j
   {
     i++;//increments index of smaller element
     swap(&arr[i], &arr[j]);
   }
 }
 swap(&arr[i + 1], &arr[high]);
 return(i + 1);
}
//end of partition function

void quickSort(int arr[], int low, int high)//quick sort function
{
 if(low<high)
 {
  //partition the array
  int pivot = partition(arr, low, high);
  
  //sort the sub arrays independently
  quickSort(arr, low, pivot - 1);
  quickSort(arr, pivot + 1, high);
 }
}
//end of quick sort function

void displayArray(int arr[], int size)//function for displaying the array
{
 int i;
 for(i = 0; i<size; i++)
   cout<<arr[i]<<" ";
}
//end if displaying function 

int main()
{
 int arr[20] = {12, 23, 3, 51, 51, 35, 19, 45, 9, 51, 54, 9, 68, 200, 245, 67, 9, 103, 12, 200};//array to be sorted
 int n = sizeof(arr)/sizeof(arr[0]);
 cout<<"Array before being sorted: "<<endl;
 displayArray(arr, n);//calls in function to display the array
 cout<<endl;
 quickSort(arr, 0, n-1);//calls in sort function
 cout<<"Array after being sorted: "<<endl;
 displayArray(arr, n);//displays the sorted array
  
 return 0;
}

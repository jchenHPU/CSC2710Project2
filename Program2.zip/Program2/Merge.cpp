#include<iostream>
using namespace std;
/*
Tarun Baskar 
csc2710-01
3/1/2022

Program 2: Team programming assignment using sorting(Merge Sort)

In this part of the program I have implimented Merge sort which will ask the user how many numbers they want to store in the array and then sort the users input of numbers that they have entered into the array.
*/

void merge(int *arr, int low, int high, int mid);
void merge_sort(int *arr, int low, int high);

void merge_sort(int *arr, int low, int high)//fuction for dividing the array into parts
//this function calls in the sort function after it has been divided 
{
 int mid;
 if(low<high)
 {
  //divides the array at mid and sort independently using merge sort
  mid = (low+high)/2;
  merge_sort(arr, low, mid);
  merge_sort(arr, mid+1, high);
  //merge or conquer sorted arrays
  merge(arr, low, high, mid);
 }
}
//end of dividing function

//merge sort
void merge(int *arr, int low, int high, int mid)//function for sorting each part of the array
//this function will merge all the integers into their correct spot after beig divided into bits
{
 int i, j, k , c[50];
 i =low;
 k = low;
 j = mid + 1;
 while(i <= mid && j <= high)
 {
   if(arr[i]<arr[j])
   {
     c[k] = arr[i];
     k++;
     i++;
   }
   else
   {
     c[k] = arr[j];
     k++;
     j++;
   }
 }
 while(i <= mid)
 { 
  c[k] = arr[i];
  k++;
  i++;
 }
 while(j <= high)
 {
  c[k] = arr[j]; 
  k++;
  j++;
 }
 for(i = low; i<k; i++)
 {
  arr[i] = c[i];
 }
}
//end of merge sort function

//read input and call mergesort
int main()
{
 int myarray[30], num;

 cout<<"Enter number of elements to be sorted: "<<endl;//asks the user how many numbers they want to store in the array
 cin>>num;
  
 cout<<"Enter "<<num<<" elements to be sorted: "<<endl;//asks user for the elements to be inputed
 for(int i = 0; i<num; i++)
 { 
  cin>>myarray[i];
 }
 merge_sort(myarray, 0, num-1);//calls in the sort function
 
 cout<<"Sorted array: "<<endl;
 for(int i = 0; i<num; i++)//displays the sorted array
 {
  cout<<myarray[i]<<" ";
 }

 return 0;
}

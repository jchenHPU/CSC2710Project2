#include<iostream>
using namespace std;
/*
Tarun Baskar
csc2710-01
2/27/2022

Program 2: Team Programming assignment on sorting(Exchange Sort)

In this part of the program I have included my algorithm for Exchange sort which sorts the numbers from highest to greatest. I have also included the number of passes that the sort takes.
*/

int main()
{
 int array[25] = {5, 67, 13, 49, 28, 2, 103, 20, 196, 80, 34, 76, 233, 45, 65, 63, 79, 12, 234 ,354, 1, 456, 23, 65, 50};
 int length = 25, i, j, temp, pass;

 cout<<"Array before being sorted: "<<endl;
 for(int t = 0; t<25; t++)//for loop for displaying array before being sorted
 {
  cout<<array[t]<<" ";
 }
 cout<<endl;
 cout<<" "<<endl;

 for(i = 0; i<(length -1); i++) //exchange sort algorithm
 {
  for(j = (i+1); j<length; j++)
  {
    if(array[i]<array[j])
    {
      temp = array[i];
      array[i] = array[j];
      array[j] = temp;
      pass++;
    }
  }
 }
 //end of exchange sort 

 for(i = 0; i<25; i++)//for loop displaying sorted array
 {
   cout<<array[i]<<" ";
 }
 cout<<endl;
 cout<<" "<<endl;

 cout<<"Number of passes: "<<pass<<endl;

 return 0;
}
